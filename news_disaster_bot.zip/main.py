
# main.py
from utils import fetch_jma, fetch_news, post_mastodon, post_misskey, image_gen, formatter

def run_bot():
    # ここで地震・ニュース取得、画像生成、投稿を呼び出す
    pass

if __name__ == "__main__":
    run_bot()
