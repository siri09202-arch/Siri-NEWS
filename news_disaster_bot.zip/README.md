# News & Disaster Bot
初心者向けニュース・地震速報Bot。
地震（震度3以上）、津波、気象警報、火山情報、Jアラート、ニュース速報をリアルタイムで投稿。
対応先：uwuzu.net、misskey.io、labo.wovs.tk、fiicen.jp
