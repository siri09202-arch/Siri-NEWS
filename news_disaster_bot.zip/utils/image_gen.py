# image_gen.py
# 実装はここに記述
