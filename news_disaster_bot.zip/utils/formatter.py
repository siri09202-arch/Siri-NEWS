# formatter.py
# 実装はここに記述
