# fetch_news.py
# 実装はここに記述
