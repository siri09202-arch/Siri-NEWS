# fetch_jma.py
# 実装はここに記述
